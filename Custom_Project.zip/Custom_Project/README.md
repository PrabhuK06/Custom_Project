# CustomProject
Custom project on Deep Learning

StepA: Deep Learning applied without normalizing data with 50 epochs,1 hidden layer & iterations of 50

StepB: Deep Learning applied with normalizing data with 50 epochs,1 hidden layer & iterations of 50

StepC: Deep Learning applied with normalizing data with 100 epochs,1 hidden layer & iterations of 50

StepB: Deep Learning applied with normalizing data with 100 epochs,3 hidden layer & iteration of 50
